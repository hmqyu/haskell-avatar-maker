# a simple avatar maker
a command line app that, when given various inputs, creates a human avatar done in a stylized format. written in haskell.
